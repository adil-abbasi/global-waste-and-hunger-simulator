import pandas as pd
import joblib
import numpy as np
import plotly.express as px
import os

# Load data & model
df = pd.read_csv('data/processed/merged_data.csv').dropna(subset=['GHI_Score'])
rf = joblib.load('models/random_forest.pkl')

# Features
features = ['Waste_Kg_Capita', 'Caloric_Surplus']
X = df[features]

# Simulate: 20% waste reduction
sim_waste = X['Waste_Kg_Capita'] * 0.8
sim_X = X.copy()
sim_X['Waste_Kg_Capita'] = sim_waste
sim_X['Caloric_Surplus'] = sim_waste * 1.5  # Update surplus
current_pred = rf.predict(X)
sim_pred = rf.predict(sim_X)
impact = current_pred - sim_pred
print("Avg GHI Reduction:", impact.mean().round(2), "(20% waste cut)")

# Monte Carlo (100 runs, ±5% noise)
np.random.seed(42)
sims = []
for _ in range(100):
    noisy_waste = sim_waste * np.random.normal(1, 0.05, len(sim_waste))
    sim_X_noisy = sim_X.copy(); sim_X_noisy['Waste_Kg_Capita'] = noisy_waste
    sim_X_noisy['Caloric_Surplus'] = noisy_waste * 1.5
    sims.append(rf.predict(sim_X_noisy).mean())
ci_low, ci_high = np.percentile(sims, [5, 95])
print("95% CI Reduction:", f"{impact.mean() - ci_high:.2f} to {impact.mean() - ci_low:.2f}")

# Viz: Impact histogram
fig = px.histogram(x=impact, nbins=20, title='GHI Reduction from 20% Waste Cut')
fig.show()
fig.write_html('outputs/figures/sim_impact.html')
print("Sim viz saved!")