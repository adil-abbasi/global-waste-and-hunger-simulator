import pandas as pd
import plotly.express as px
import matplotlib.pyplot as plt
import seaborn as sns
import os

# Load merged
df = pd.read_csv('data/processed/merged_data.csv')
print("Loaded Shape:", df.shape)
print("Cols:", df.columns.tolist())
print("Nulls:\n", df.isnull().sum())

# EDA Basics
print("\nStats:\n", df.describe())
corr = df[['GHI_Score', 'Waste_Kg_Capita']].corr()
print("Waste-Hunger Corr:", corr.iloc[0,1])  # Expect negative

# Viz 1: Correlation Heatmap (Matplotlib)
plt.figure(figsize=(6,4))
sns.heatmap(corr, annot=True, cmap='RdBu')
plt.title('Waste vs Hunger Correlation')
os.makedirs('outputs/figures', exist_ok=True)
plt.savefig('outputs/figures/corr_heatmap.png')
plt.show()

# Viz 2: Global Hunger Map (Plotly, 2025 only)
latest = df[df['Year'] == 2025].copy()
if latest.empty:
    print("No 2025 data? Use max year:", df['Year'].max())
    latest = df[df['Year'] == df['Year'].max()]
fig_map = px.choropleth(latest, locations='Country', color='GHI_Score',
                        title=f'Hunger Map ({latest["Year"].iloc[0]})',
                        color_continuous_scale='Reds',
                        hover_data=['Waste_Kg_Capita'])
fig_map.show()  # Browser opens

# Viz 3: Waste-Hunger Scatter (all years)
fig_scatter = px.scatter(df, x='Waste_Kg_Capita', y='GHI_Score', color='Year',
                         title='Waste vs Hunger by Year',
                         trendline='ols')  # Linear fit
fig_scatter.show()

# Save HTML
fig_map.write_html('outputs/figures/hunger_map.html')
print("Vizes done! Check browser/outputs/figures/")