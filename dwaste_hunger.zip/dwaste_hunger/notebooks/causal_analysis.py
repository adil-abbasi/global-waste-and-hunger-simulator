import pandas as pd
from dowhy import CausalModel
import graphviz

df = pd.read_csv('data/processed/merged_data.csv').dropna(subset=['GHI_Score'])
df['Waste_Reduction'] = df['Waste_Kg_Capita'] * -0.1  # Proxy for reduction (10% cut)

model = CausalModel(
    data=df,
    treatment='Waste_Reduction',  # Intervention
    outcome='GHI_Score',
    graph="digraph {Waste_Reduction -> GHI_Score; GDP_Per_Capita -> Waste_Reduction; GDP_Per_Capita -> GHI_Score;}"
)

identified_estimand = model.identify_effect()
causal_estimate = model.estimate_effect(identified_estimand, method_name="backdoor.linear_regression")
print("Causal Effect:", causal_estimate.value)  # E.g., -0.05 GHI per unit reduction

# Refutation (robustness)
refutation = model.refute_estimate(identified_estimand, causal_estimate, method_name="random_common_cause")
print("Refutation p-value:", refutation.p_value)  # >0.05 = robust

# Save DAG plot
model.view_model(layout="dot")
from IPython.display import Image
Image('causal_model.png')  # Run in Jupyter for viz