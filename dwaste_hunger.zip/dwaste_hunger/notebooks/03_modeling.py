import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.ensemble import RandomForestRegressor
from sklearn.metrics import mean_squared_error
import xgboost as xgb
import joblib
import numpy as np
import os

# Load (drop null GHI)
df = pd.read_csv('data/processed/merged_data.csv').dropna(subset=['GHI_Score'])
print("Clean Shape:", df.shape)
print("Columns:", df.columns.tolist())

# Safe GDP fill
if 'GDP_Per_Capita' not in df.columns:
    df['GDP_Per_Capita'] = 12000  # Global avg
else:
    df['GDP_Per_Capita'] = df['GDP_Per_Capita'].fillna(12000)

# Features
features = ['Waste_Kg_Capita', 'Caloric_Surplus', 'GDP_Per_Capita']
X = df[features]
# Flip waste (for +corr)
X['Waste_Kg_Capita'] = -X['Waste_Kg_Capita']
X['Caloric_Surplus'] = -X['Caloric_Surplus']
y = df['GHI_Score']
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

# XGBoost (primary for dashboard – better non-linear)
xgb_model = xgb.XGBRegressor(n_estimators=200, learning_rate=0.1, max_depth=5, random_state=42)  # Tuned for sensitivity
xgb_model.fit(X_train, y_train)
y_pred_xgb = xgb_model.predict(X_test)
xgb_rmse = np.sqrt(mean_squared_error(y_test, y_pred_xgb))
print("XGBoost RMSE:", xgb_rmse)

# RF for comparison
rf = RandomForestRegressor(n_estimators=100, random_state=42)
rf.fit(X_train, y_train)
y_pred_rf = rf.predict(X_test)
rf_rmse = np.sqrt(mean_squared_error(y_test, y_pred_rf))
print("RF RMSE:", rf_rmse)

imp = pd.DataFrame({'Feature': features, 'Imp': xgb_model.feature_importances_})  # XGBoost imp
print("XGBoost Importance:\n", imp)

# Save XGBoost as 'rf' for dashboard compat
os.makedirs('models', exist_ok=True)
joblib.dump(xgb_model, 'models/random_forest.pkl')  # Rename for drop-in
joblib.dump(rf, 'models/random_forest_original.pkl')
print("Models saved! (XGBoost as main for sensitivity)")