import folium
from folium.plugins import MarkerCluster
import pandas as pd

df = pd.read_csv('data/processed/merged_data.csv')
latest = df[df['Year'] == 2025].dropna(subset=['GHI_Score'])

m = folium.Map(location=[0, 0], zoom_start=2, tiles='OpenStreetMap')
cluster = MarkerCluster().add_to(m)

for idx, row in latest.iterrows():
    folium.Marker(
        location=[0, 0],  # Use geopy for lat/lon (pip install geopy; add in prep)
        popup=f"<b>{row['Country']}</b><br>GHI: {row['GHI_Score']}<br>Waste: {row['Waste_Kg_Capita']}kg",
        icon=folium.Icon(color='red' if row['GHI_Score'] > 10 else 'green', icon='info-sign')
    ).add_to(cluster)

m.save('outputs/figures/interactive_map.html')
print("Saved interactive_map.html")