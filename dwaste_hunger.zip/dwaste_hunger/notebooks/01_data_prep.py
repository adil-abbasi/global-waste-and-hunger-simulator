import pandas as pd
import os
import numpy as np

# Load GHI (unchanged)
def load_ghi():
    file = 'data/raw/ghi_2025.xlsx'
    df = pd.read_excel(file, sheet_name=0, header=None, skiprows=4)
    df = df.iloc[:, 2:]
    df.columns = ['Country', 'Undernour_Pct', 'Stunting_Pct', 'Wasting_Pct', 'Mortality_Pct']
    df['Year'] = 2025
    for col in ['Undernour_Pct', 'Stunting_Pct', 'Wasting_Pct', 'Mortality_Pct']:
        df[col] = pd.to_numeric(df[col].replace('<5', 4.9), errors='coerce')
    df['GHI_Score'] = df[['Undernour_Pct', 'Stunting_Pct', 'Wasting_Pct', 'Mortality_Pct']].mean(axis=1)
    df = df[['Country', 'Year', 'GHI_Score']].dropna(subset=['Country', 'GHI_Score'])
    df['Country'] = df['Country'].str.strip()
    return df

# Load FAO Waste (unchanged)
def load_fao_waste():
    file = 'data/raw/fao_flw_2025.csv'
    df = pd.read_csv(file)
    df = df[df['food_supply_stage'].str.contains('Retail|Consumer', case=False, na=False)]
    df['Waste_Pct'] = pd.to_numeric(df['loss_percentage'], errors='coerce')
    df_group = df.groupby(['country', 'year'])['Waste_Pct'].mean().reset_index()
    df_group.columns = ['Country', 'Year', 'Waste_Kg_Capita']
    return df_group.dropna()

# Load OWID GHI (unchanged)
def load_owid_ghi():
    file = 'data/raw/owid_ghi_2025.csv'
    df = pd.read_csv(file)
    df = df.rename(columns={'Entity': 'Country', 'Global Hunger Index (2021)': 'GHI_Score'})
    df = df[['Country', 'Year', 'GHI_Score']].dropna()
    return df

# Load OWID Waste (unchanged)
def load_owid_waste():
    file = 'data/raw/owid_waste_2025.csv'
    df = pd.read_csv(file)
    df = df.rename(columns={'Entity': 'Country'})
    hh_col = [col for col in df.columns if 'Households' in col][0]
    df['Waste_Kg_Capita'] = pd.to_numeric(df[hh_col], errors='coerce')
    df = df[['Country', 'Year', 'Waste_Kg_Capita']].dropna()
    return df

# Load Kaggle Waste (unchanged)
def load_kaggle_waste():
    file = 'data/raw/global_food_wastage.csv'
    df = pd.read_csv(file)
    df = df.rename(columns={'Avg Waste per Capita (Kg)': 'Waste_Kg_Capita'})
    df['Waste_Kg_Capita'] = pd.to_numeric(df['Waste_Kg_Capita'], errors='coerce')
    df = df[['Country', 'Year', 'Waste_Kg_Capita']].dropna()
    return df

# Load GDP (Fixed: Double quotes for apostrophe keys)
def load_gdp(ghi_countries):
    gdp_dict = {
        'Belarus': 7500, 'Bosnia & Herzegovina': 7000, 'Bulgaria': 14000, 'Chile': 15000, 'China': 13000,
        'India': 2500, 'Pakistan': 1500, 'USA': 80000, 'Nigeria': 2000, 'Brazil': 9000, 'Afghanistan': 500, 'Albania': 6500,
        'Algeria': 4500, 'Angola': 2500, 'Argentina': 13000, 'Armenia': 7000, 'Azerbaijan': 5500, 'Bangladesh': 2800,
        'Benin': 1300, 'Bhutan': 3500, 'Bolivia': 3500, 'Botswana': 7000, 'Burkina Faso': 900, 'Burundi': 200,
        'Cambodia': 1800, 'Cameroon': 1500, 'Central African Republic': 500, 'Chad': 700, 'Comoros': 1500, 'Congo': 2300,
        "Cote d'Ivoire": 2500, 'Djibouti': 3500, 'Dominican Republic': 10000, 'Egypt': 4000, 'El Salvador': 5000,
        'Eritrea': 600, 'Eswatini': 4000, 'Ethiopia': 1000, 'Gabon': 8000, 'Gambia': 800, 'Ghana': 2300, 'Guatemala': 5000,
        'Guinea': 1200, 'Guinea-Bissau': 800, 'Haiti': 1700, 'Honduras': 3000, 'Iran': 5000, 'Iraq': 5500,
        'Jordan': 4500, 'Kenya': 2000, 'Kiribati': 1800, 'Korea DPR': 1000, 'Kuwait': 35000, 'Kyrgyz Republic': 1600,
        'Lao PDR': 2500, 'Lebanon': 4000, 'Lesotho': 1100, 'Liberia': 700, 'Libya': 7000, 'Madagascar': 500,
        'Malawi': 400, 'Malaysia': 12000, 'Maldives': 11000, 'Mali': 900, 'Mauritania': 2000, 'Mauritius': 11000,
        'Micronesia': 3500, 'Mozambique': 500, 'Myanmar': 1200, 'Namibia': 4500, 'Nauru': 12000, 'Nepal': 1400,
        'Nicaragua': 2300, 'Niger': 600, 'North Macedonia': 7000, 'Oman': 25000, 'Pakistan': 1500, 'Palau': 14000,
        'Papua New Guinea': 3000, 'Rwanda': 1000, 'Sao Tome and Principe': 2500, 'Senegal': 1600, 'Sierra Leone': 700,
        'Solomon Islands': 2200, 'Somalia': 500, 'South Sudan': 400, 'Sri Lanka': 4000, 'Sudan': 800, 'Suriname': 6000,
        'Syrian Arab Republic': 1000, 'Tajikistan': 1100, 'Tanzania': 1200, 'Timor-Leste': 1500, 'Togo': 1000,
        'Tonga': 5000, 'Tunisia': 4000, 'Turkmenistan': 7000, 'Tuvalu': 5000, 'Uganda': 1000, 'Ukraine': 5000,
        'Uzbekistan': 2000, 'Vanuatu': 3200, 'Venezuela': 3500, 'Vietnam': 4500, 'Yemen': 700, 'Zambia': 1400,
        'Zimbabwe': 1500
    }
    gdp_df = pd.DataFrame({
        'Country': list(gdp_dict.keys()),
        'Year': 2025,
        'GDP_Per_Capita': list(gdp_dict.values())
    })
    # Fallback for missing
    missing_countries = [c for c in ghi_countries if c not in gdp_dict]
    if missing_countries:
        gdp_df = pd.concat([gdp_df, pd.DataFrame({'Country': missing_countries, 'Year': 2025, 'GDP_Per_Capita': 12000})])
    return gdp_df

# Load all + merge (unchanged from previous)
ghi = load_ghi()
fao_waste = load_fao_waste()
owid_ghi = load_owid_ghi()
owid_waste = load_owid_waste()
kaggle_waste = load_kaggle_waste()
gdp = load_gdp(ghi['Country'].unique())

print("GHI Shape:", ghi.shape)
print("FAO Waste Shape:", fao_waste.shape)
print("OWID GHI Shape:", owid_ghi.shape)
print("OWID Waste Shape:", owid_waste.shape)
print("Kaggle Waste Shape:", kaggle_waste.shape)

merged = pd.merge(ghi, fao_waste, on=['Country', 'Year'], how='outer')
merged = pd.merge(merged, owid_ghi, on=['Country', 'Year'], how='outer', suffixes=('', '_owid'))
merged['GHI_Score'] = merged['GHI_Score'].fillna(merged.get('GHI_Score_owid', np.nan))
merged = merged.drop(columns=['GHI_Score_owid'], errors='ignore')
merged = pd.merge(merged, owid_waste, on=['Country', 'Year'], how='outer', suffixes=('', '_owidw'))
merged['Waste_Kg_Capita'] = merged['Waste_Kg_Capita'].fillna(merged.get('Waste_Kg_Capita_owidw', np.nan))
merged = merged.drop(columns=['Waste_Kg_Capita_owidw'], errors='ignore')
merged = pd.merge(merged, kaggle_waste, on=['Country', 'Year'], how='outer', suffixes=('', '_kaggle'))
if 'Waste_Kg_Capita_kaggle' in merged.columns:
    merged['Waste_Kg_Capita'] = merged['Waste_Kg_Capita'].fillna(merged['Waste_Kg_Capita_kaggle'])
    merged = merged.drop(columns=['Waste_Kg_Capita_kaggle'])
merged['Waste_Kg_Capita'] = merged['Waste_Kg_Capita'].fillna(0)
merged['Waste_Kg_Capita'] = merged.groupby('Year')['Waste_Kg_Capita'].transform(lambda x: x.fillna(x.mean()))
merged = pd.merge(merged, gdp, on=['Country', 'Year'], how='outer')
merged['GDP_Per_Capita'] = merged.groupby('Country')['GDP_Per_Capita'].fillna(method='ffill').fillna(12000)
merged['Caloric_Surplus'] = merged['Waste_Kg_Capita'] * 1.5

print("\nMerged Shape:", merged.shape)
os.makedirs('data/processed', exist_ok=True)
merged.to_csv('data/processed/merged_data.csv', index=False)
print("Saved!")